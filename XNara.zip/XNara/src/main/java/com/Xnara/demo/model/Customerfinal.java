package com.Xnara.demo.model;

import java.util.List;

public class Customerfinal {
	
	private int customer_id;
	private int id;
	private List<String> pack_data1;
	private List<String> pack_data2;
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public List<String> getPack_data1() {
		return pack_data1;
	}
	public void setPack_data1(List<String> pack_data1) {
		this.pack_data1 = pack_data1;
	}
	public List<String> getPack_data2() {
		return pack_data2;
	}
	public void setPack_data2(List<String> pack_data2) {
		this.pack_data2 = pack_data2;
	}

		
}
