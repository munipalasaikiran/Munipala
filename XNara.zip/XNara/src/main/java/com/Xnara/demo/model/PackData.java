package com.Xnara.demo.model;

import jakarta.persistence.ManyToOne;

public class PackData {
	
	private String inventory_code;
    private String ingredient;
    private int quantity;
    private String unit;
   
	public String getInventory_code() {
		return inventory_code;
	}
	public void setInventory_code(String inventory_code) {
		this.inventory_code = inventory_code;
	}
	public String getIngredient() {
		return ingredient;
	}
	public void setIngredient(String ingredient) {
		this.ingredient = ingredient;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	
}
