package com.Xnara.demo.model;

import java.util.List;

public class Customer {
	
	private int customer_id;
	private int id;
	private List<PackData> pack_data;
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public List<PackData> getPack_data() {
		return pack_data;
	}
	public void setPack_data(List<PackData> pack_data) {
		this.pack_data = pack_data;
	}
	
	
}
