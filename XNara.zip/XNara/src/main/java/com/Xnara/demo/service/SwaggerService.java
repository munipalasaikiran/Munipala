package com.Xnara.demo.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.Xnara.demo.model.Customer;
import com.Xnara.demo.model.Customerfinal;

import reactor.core.publisher.Mono;

@Service
public class SwaggerService {
	
	private final WebClient webClient;
	
	public SwaggerService(WebClient.Builder webClientBuilder)
	{
		this.webClient=webClientBuilder.baseUrl("https://6466e9a7ba7110b663ab51f2.mockapi.io/api/v1").build();
	}
	
	public Customerfinal datadetails(int customer_id)
	{
		Mono<ResponseEntity<Customer>> c1=this.webClient.get().uri("/pack1").retrieve().toEntity(Customer.class);
		Mono<ResponseEntity<Customer>> c2=this.webClient.get().uri("/pack2").retrieve().toEntity(Customer.class);
		Customerfinal c=new Customerfinal();
		c.setCustomer_id(customer_id);
		
		return c;
		
	}
	

}
