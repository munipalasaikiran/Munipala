package com.Xnara.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XNaraApplication {

	public static void main(String[] args) {
		SpringApplication.run(XNaraApplication.class, args);
	}

}
